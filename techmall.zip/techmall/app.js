const express = require('express')
const path = require('path')
const cookieParser = require('cookie-parser')
const expressSession = require('express-session')
const fileUpload = require('express-fileupload')
const cors = require('cors');

const server = express()

// enable CORS
server.use(cors());

const adminRoute = require('./server/routers/AdminRoute')
const userRoute = require('./server/routers/UserRoute')

server.use(express.static(path.join(__dirname,"build")))
server.use(express.json()) 
server.use(fileUpload())
server.use(cookieParser())
server.use(expressSession({secret:"universal informatics"}))

server.use('/admin',adminRoute)
server.use("/user",userRoute)

server.get("/checksession",(request,response)=>
{
    if(request.session.user==undefined)
        response.send({status:false})
    else
        response.send({status:true,type:request.session.user.type})        
})

server.listen(8000,()=>{
    console.log("http://localhost:8000")
})