import React from 'react'

export default class AdminHome extends React.Component
{
    constructor(props){
        super(props)
    }
    render(){
        return <div>
            <h1>Admin Home</h1>
        </div>
    }
}