const server = "http://localhost:8000/";

export const ADMIN_LOGIN = server + "admin/login";
export const ADMIN_CATEGORY = server + "admin/category";
export const ADMIN_PRODUCT = server + "admin/product";
export const ADMIN_SEARCH_PRODUCT = server + "admin/searchproduct";
export const ADD_CART = server + "admin/addcart";
export const LOAD_CART = server + "admin/loadcart";
export const REMOVE_ITEM_CART = server + "admin/removecartitem";
export const LOAD_PRODUCT = server + "admin/getproduct";
export const PRODUCT_UPLOAD_PIC = server + "admin/uploadpic"

export const USER_REGISTER = server + "user/register"
export const USER_LOGIN = server + "user/login"

export const USER_PAYMENT = server + "user/pay"




export const LOGOUT = server + "checksession";

